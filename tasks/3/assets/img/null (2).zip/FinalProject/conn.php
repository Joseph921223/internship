 <?php
 
 $server = "127.0.0.1";
 $username = "root";
 $password = "";
 $database = "vehicle_parts";
 
 $con = mysql_connect($server,$username,$password)
 
or die ("Could'nt connect to server");

 
 $db = mysql_select_db($database,$con)
 
 or die ("Could'nt select database");
 
 
  
 ?>