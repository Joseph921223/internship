<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
<?php

session_start();
ob_start();

if(!isset($_SESSION["user"]))
{

header("Location: index.php");

}

?>   
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Admin Dashboard</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <script language="JavaScript" type="text/javascript" src="js/calender.js"></script>
    <script language="JavaScript" type="text/javascript" src="js/events.js"></script>
</head>
<body  background="1.jpg">
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-png"></div>
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-logo">
                                 <h1 style="color:#0000ff;" class="art-logo-name">ALTHEALTH ONLINE CARE-SHOP </h1>
                                                 <h2 class="art-logo-text">The number one online health system you can trust</h2>
												
                                </div>
            </div>
            <div class="cleared reset-box"></div>
<div class="art-nav">
    <div class="art-nav-l"></div>
    <div class="art-nav-r"></div>
<div class="art-nav-outer">
    <ul class="art-hmenu">   
        <li>
            <a href="admin_dashboard.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Admin Dashboard</span></a>
        </li>
        <li>
            <a href="update_order.php"><span class="l"></span><span class="r"></span><span class="t">Update Customer Order</span></a>
        </li><li>
        
            <?php

if(!isset($_SESSION["user"]))
{
    echo '<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>';

}
else
{

   echo '<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>';

}
?>
        </li>
    </ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    <div class="art-layout-cell art-sidebar1">
<div class="art-vmenublock">
    <div class="art-vmenublock-body">
               

    </div>
</div>
<div class="art-block">
    <div class="art-block-body">
                
                <div class="art-blockcontent">
                
                </div>
        <div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                    <div class="art-layout-cell art-content">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner ">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<?php

include('conn.php');
@$user = $_SESSION['user'];

if(@$_SESSION['usertype'] == "Customer")
{
    @$select = mysql_query("SELECT * FROM user WHERE username = '$user'");
    @$row = mysql_fetch_array($select);
    echo "<font size='2px'>Welcome <b>". $name = $row['first_name'].' '.$surname = $row['last_name'].'</b>, customer</font>';
}
if(@$_SESSION['usertype'] == "Admin")
{
    @$admin_select = mysql_query("SELECT * FROM admin WHERE admin_name = '$user'");
    @$rows = mysql_fetch_array($admin_select);
    echo "<font size='2px'>You are logged in as <b>". $admin = $rows['admin_name'].'</b>, admin</font>';
}
?>
                                <h2 class="art-postheader">
               Administrator
                                </h2>
                                
            

<br><label><b>ADD/ UPDATE/ DELETE PRODUCTS</b></label>                              
<table border ='0' width="" style="background-color: ; color: "><tr style='background-color: #7999DD'>
<td><strong>Product Name</strong></td><td><strong>Description</strong></td><td><strong>Available stock</strong></td>
<td><strong>Brand Name</strong></td><td><strong>Price</strong></td><td colspan='2'><strong>Action</strong></td></tr>
<?php
include("conn.php");

@$result = mysql_query("SELECT * FROM products ORDER BY product_id ");  
while(@$row = mysql_fetch_array($result)){

$product_id=$row['product_id'];


echo "<tr><td><br>";
echo $row['name'];
echo "</td><td><br>";
echo $row['description'];
echo"</td><td><br>";
echo $row['nr_of_products'];
echo "</td><td><br>";
echo $row['brand'];
echo "</td><td><br>R";
echo number_format($row['price']);
echo "</td><td><br>";
echo "<a href=update_product.php?product_id=$product_id&insert=yes>Edit</a>";
echo "</td>";
echo "<td><br>";
echo "<a href=delete_product.php?product_id=$product_id&insert=yes>Remove</a>";
echo "</td>";
echo "</tr>";

}
echo "</table><br>";
echo "<a href='add_product.php'>Add New Product</a>";



?>
              <div class="cleared"></div>
                                <div class="art-postcontent">

                </div>
                <div class="cleared"></div>
                </div>

        <div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                </div>
            </div>
            
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
            <div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
 
</div>

</body>
</html>
