<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <!--
    Created by Reneilwe
    
    -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Registration</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <script language="JavaScript" type="text/javascript" src="js/calender.js"></script>
    <script language="JavaScript" type="text/javascript" src="js/events.js"></script>
</head>
<body  background="1.jpg">
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-png"></div>
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-logo">
                                 <h1 style="color:#0000ff;" class="art-logo-name">ALTHEALTH ONLINE CARE-SHOP </h1>
                                                 <h2 class="art-logo-text">The number one online health system you can trust</h2>
												 <img src="e.jpg" alt="" height="600" width="770">
                                </div>
                                
            </div>
            <div class="cleared reset-box"></div>
<div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
	<ul class="art-hmenu">
		<li>
			<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="product.php"><span class="l"></span><span class="r"></span><span class="t">Product</span></a>
		</li>
        <li>
            <a href="search.php"><span class="l"></span><span class="r"></span><span class="t">Search</span></a>
        </li>
        
             <li>
            <a href="register.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Register</span></a>
        </li>
		<li>
            <a href="usermanual.php"><span class="l"></span><span class="r"></span><span class="t">User Manual</span></a>
        </li>
		 
        	 <li>
            <?php
ob_start();
session_start();

if(!isset($_SESSION["user"]))
{
    echo '<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>';

}
else
{
   echo '<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>';

}
?>
        </li>
	</ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    <div class="art-layout-cell art-sidebar1">
<div class="art-vmenublock">
    <div class="art-vmenublock-body">
               
    </div>
</div>
<div class="art-block">
    <div class="art-block-body">
                
                <div class="art-blockcontent">
                
                </div>
		<div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                    <div class="art-layout-cell art-content">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner art-article">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<?php

include('conn.php');
@$user = $_SESSION['user'];

if(@$_SESSION['usertype'] == "Customer")
{
    @$select = mysql_query("SELECT * FROM user WHERE username = '$user'");
    @$row = mysql_fetch_array($select);
    echo "<font size='2px'>Welcome <b>". $name = $row['first_name'].' '.$surname = $row['last_name'].'</b>, customer</font>';
}
if(@$_SESSION['usertype'] == "Admin")
{
    @$admin_select = mysql_query("SELECT * FROM admin WHERE admin_name = '$user'");
    @$rows = mysql_fetch_array($admin_select);
    echo "<font size='2px'>You are logged in as <b>". $admin = $rows['admin_name'].'</b>, admin</font>';
}
?>
                                <h2 class="art-postheader">
               New user registration
                                </h2>
<table height='' style='color: #996666; color: #996666' width=''><form action='register.php' method='POST'>

<tr><td>Username: </td><td><input type='text' name='username' required="required" size='27' placeholder='Enter your username'></td></tr> <tr><td>Title: </td><td><select name='title'>
<option>--Select Title--</option>
<option>Mr</option>
<option>Ms</option>
<option>Mrs</option>
</select></td></tr>                               
<tr><td>First Name: </td><td><input type='text' required="required" name='first_name' size='27' placeholder='Enter your first name'></td></tr> 
<tr><td>Middle Name: </td><td><input type='text' required="required" name='middle_name' size='27' placeholder='Enter your middle name'></td></tr>
<tr><td>Last Name: </td><td><input type='text' name='last_name' size='27' required="required" placeholder='Enter your last name'></td></tr>
<tr><td>Email: </td><td><input type='email' required="required" name='email' size='27' placeholder='Enter your email address'></td></tr>
<tr><td>Contact Number: </td><td><input type='number' required="required" name='number' size='27' placeholder='Enter contact number'></td></tr>
<tr><td>Password: </td><td><input type='text' required="required" name='password' size='27' placeholder='Enter your password'></td></tr> 
<tr><td>Confirm Password: </td><td><input type='e' required="required" name='confirm' size='27' placeholder='Confirm password'></td></tr>   
<tr><td> Address: </td><td><input type='text' required="required" name='r_address' size='27' placeholder='Enter  address'></td></tr> 
<tr><td>Province: </div></td><td><select name="Province">
    <option>---Select Province---</option>
     <option>Select state                       
     <option>Mpumalanga</option>                        
    <option>Gauteng </option>                        
    <option>Limpopo </option>                        
    <option>Kwazulu Natal</option>                        
    <option>Free state</option>                        
    <option>Western cape</option>                        
   <option>Eastern cape </option>                        
   <option>Northern cape</option>                        
   <option>North west province</option></td></tr> 
   <tr><td><input type='submit' style='background-color: #996666; color: #000000' name='submit' value='Register'></td><td><input type='submit' style='background-color: #FF9966; color: #3366CC' name='reset' value='Clear Fields'></td></tr>
</form></table><br>

<?php
                include("connect.php"); 
                function register($username, $title, $first_name, $middle_name, $last_name, $email, $phone, $state, $r_address, $password)
                {
                global $db;
                $insert = "INSERT INTO user(username,title,first_name,middle_name,last_name,email,password,address,phone,state) 
                VALUES('$username','$title','$first_name','$middle_name','$last_name','$email','$password','$r_address','$phone','$state')";
                $execute = $db->exec($insert);
                return $execute;
                }
                @$username= $_POST['username'];
                @$title = $_POST['title'];
                @$first_name = $_POST['first_name'];
                @$middle_name= $_POST['middle_name'];
                @$last_name= $_POST['last_name'];
                @$email = $_POST['email'];
                @$phone = $_POST['phone'];
                @$state= $_POST['state'];
                @$r_address = $_POST['r_address'];
                @$password= $_POST['password'];
                @$confirm = $_POST['confirm'];
               
           
                if(@$_POST['submit'] == "Register")
                {
                    
                    @$search = "SELECT username FROM user WHERE  username= '$username'";
                    $query = $db->query($search);
                    $count = count($query->fetchAll());
                    
                    if($count > 0)
                    {
                        echo '<script language="javascript">';
                        echo 'alert("Username entered already exist!")';
                        echo '</script>';
                      
                    }
                    elseif($title == "--Select Title--")
                    {
                        echo '<script language="javascript">';
                        echo 'alert("Please select your title!")';
                        echo '</script>';
                        
                    }
                    elseif($state == "---Select state---")
                    {
                        echo '<script language="javascript">';
                        echo 'alert("Please select your state!")';
                        echo '</script>';
                        
                    }
                    elseif($password != $confirm)
                    {
                        echo '<script language="javascript">';
                        echo 'alert("Passwords are not the same!")';
                        echo '</script>';
                    
                    }
                    else
                    {
                        $insert= register($username, $title, $first_name, $middle_name, $last_name, $email, $phone, $state, $r_address, $password);
                        echo '<script language="javascript">';
                        echo 'alert("You are successfully registered into our database.")';
                        echo '</script>';
                        echo "Click <a href='index.php'>here</a> to login...";
                    }
                    
                }
                        
                ?>

                <div class="cleared"></div>
                                <div class="art-postcontent">

                </div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-t"></div>
                <div class="art-footer-l"></div>
                <div class="art-footer-b"></div>
                <div class="art-footer-r"></div>
                <div class="art-footer-body">
                            <div class="art-footer-text"><br>
                                <p> Copyright © 2018 ATHEALTH SYSTEM. All Rights Reserved.</p>
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
   
</div>

</body>
</html>
