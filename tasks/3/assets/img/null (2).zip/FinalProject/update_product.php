<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
<?php

session_start();
ob_start();

if(!isset($_SESSION["user"]))
{

header("Location: index.php");

}

?>   
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Admin Dashboard - Delete Product</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <script language="JavaScript" type="text/javascript" src="js/calender.js"></script>
    <script language="JavaScript" type="text/javascript" src="js/events.js"></script>
</head>
<body background="1.jpg">
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-png"></div>
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-logo">
                               <h1 style="color:#0000ff;" class="art-logo-name">ALTHEALTH ONLINE CARE-SHOP </h1>
                                                 <h2 class="art-logo-text">The number one online health system you can trust</h2>
                                </div>
            </div>
            <div class="cleared reset-box"></div>
<div class="art-nav">
    <div class="art-nav-l"></div>
    <div class="art-nav-r"></div>
<div class="art-nav-outer">
    <ul class="art-hmenu">  
        <li>
            <a href="admin_dashboard.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Admin Dashboard</span></a>
        </li>
        <li>
            <a href="update_orders.php"><span class="l"></span><span class="r"></span><span class="t">Update Customer Order</span></a>
        </li><li>
            <?php

if(!isset($_SESSION["user"]))
{
    echo '<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>';

}
else
{

   echo '<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>';

}
?>
        </li>
    </ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    <div class="art-layout-cell art-sidebar1">
<div class="art-vmenublock">
    <div class="art-vmenublock-body">
               

    </div>
</div>
<div class="art-block">
    <div class="art-block-body">
                
                <div class="art-blockcontent">
                
                </div>
        <div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                    <div class="art-layout-cell art-content">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner ">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<?php

include('conn.php');
@$user = $_SESSION['user'];

if(@$_SESSION['usertype'] == "Customer")
{
    @$select = mysql_query("SELECT * FROM user WHERE username = '$user'");
    @$row = mysql_fetch_array($select);
    echo "<font size='2px'>Welcome <b>". $name = $row['first_name'].' '.$surname = $row['last_name'].'</b>, customer</font>';
}
if(@$_SESSION['usertype'] == "Admin")
{
    @$admin_select = mysql_query("SELECT * FROM admin WHERE admin_name = '$user'");
    @$rows = mysql_fetch_array($admin_select);
    echo "<font size='2px'>You are logged in as <b>". $admin = $rows['admin_name'].'</b>, admin</font>';
}
?>
                                <h2 class="art-postheader">
               Administrator 
                                </h2>
                                
<br><label><b>UPDATE PRODUCT</b></label><br><br>                              
<table height='' width='' ><form action='update_product.php' method='GET'>
<?php
include("conn.php");

@$get_id = $_GET['product_id'];

@$select= mysql_query("SELECT * FROM products WHERE product_id = '$get_id'");
@$row = mysql_fetch_array($select);
@$ID = $row['product_id'];
@$name=  $row['name'];
@$descr = $row['description'];
@$nr_product = $row['nr_of_products'];
@$brand = $row['brand'];
@$price = $row['price'];

echo "<input type='hidden' name='id' value='$ID'>";
echo "<tr><td>Name:</b></td><td><input type='text'  name='name' value='$name' size='26'  required='required'></td></tr>";
echo "<tr><td>Description:</td><td><input type='text'  value='$descr' name='description' size='26' required='required'></td></tr>";
echo "<tr><td>Number of products:</td><td><input type='number' value='$nr_product' size='26' name='product_num' required='required'></td></tr>";
echo "<tr><td>Brand:</td><td><input type='text'  name='brand' value='$brand' size='26' required='required'></td></tr>";
echo "<tr><td>Price:</td><td><input type='text'  name='price' value='$price' size='26' required='required'></td></tr>";
echo "<tr><td><input style='background-color: #FF9966; color: #3366CC' type='submit' name='submit' value='Update Product'></td><td><a href='admin_dashboard.php'><b>Back</b></a></td></tr><form></table><br>";

@$id = $_GET['id'];
@$name=  $_GET['name'];
@$description = $_GET['description'];
@$nr_product = $_GET['product_num'];
@$brand = $_GET['brand'];
@$price = $_GET['price'];

@$update = "UPDATE products SET name='$name', description='$description', nr_of_products='$nr_product', brand='$brand', price='$price' WHERE product_id='$id'";
if(@$_GET['submit']== "Update Product")
{
    mysql_query($update);
    header("Location: admin_dashboard.php");
}

?>
              <div class="cleared"></div>
                                <div class="art-postcontent">

                </div>
                <div class="cleared"></div>
                </div>

        <div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                </div>
            </div>
           
                    <div class="cleared"></div>
                </div>
            </div>
            <div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
   
</div>

</body>
</html>
