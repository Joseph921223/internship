<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
   
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Home</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <script language="JavaScript" type="text/javascript" src="js/calender.js"></script>
    <script language="JavaScript" type="text/javascript" src="js/events.js"></script>
</head>
<body>
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-png"></div>
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-logo">
                                 <h1 class="art-logo-name">ATHEALTH </h1>
                                                 <h2 class="art-logo-text">The number one online health system you can trust</h2>
                                </div>
                                
            </div>
            <div class="cleared reset-box"></div>
<div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
	<ul class="art-hmenu">
		<li>
			<a href="index.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="product.php"><span class="l"></span><span class="r"></span><span class="t">Product</span></a>
		</li>
        <li>
            <a href="search.php"><span class="l"></span><span class="r"></span><span class="t">Search</span></a>
        </li>
         
             <li>
           
             <li>
            <a href="register.php"><span class="l"></span><span class="r"></span><span class="t">Register</span></a>
        </li>
        	 <li>
			 <li>
            <a href="usermanual.php"><span class="l"></span><span class="r"></span><span class="t">User Manual</span></a>
        </li>
		 
			 
            

            <?php
ob_start();
session_start();
if(!isset($_SESSION["user"]))
{
    echo '<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>';

}
else
{
   echo '<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>';

}
?>

        </li>
	</ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    <div class="art-layout-cell art-sidebar1">
<div class="art-vmenublock">
    <div class="art-vmenublock-body">
                <div class="art-vmenublockheader"><br><br>
                    <h3 class="t">Login </h3>

                </div>
                <div class="art-vmenublockcontent">
                    <div class="art-vmenublockcontent-body"><br><br><br>
<table height='' width='' style='background-color: #Yellow'><form action='index.php' method='POST'>
    <tr><td>User Type: <br>
            <select name='user_type'>
            <option>Select user type</option>
            <option>Customer</option>
            <option>Admin</option>
            </select><br></tr>
    <tr><td>Username:</td></tr><tr><td><input type='text' required="required" placeholder='Enter username' name='username'></td></tr>
    <tr><td>Password:</td></tr><tr><td><input type='text' placeholder='Enter password' required="required" name='password'></td></tr>
    <tr><td><input type='submit' style='background-color: #black; color: #3366CC' name='submit' value='Login'></td></tr></table>
<br><br><br><br><br><br><br>
 <?php


include("connect.php");

@$usertype = $_POST['user_type'];
if($usertype == "Customer")
{   

@$username =$_POST['username'];
@$password = $_POST['password'];
@$Check1 = "SELECT * FROM user WHERE username = '$username' AND password='$password'";
                    $query = $db->query($Check1);
                    $count1 = count($query->fetchAll());

if(@$_POST['submit'] == "Login"){

 if(@$count1 <= 0 ){
 
echo '<script language="javascript">';
echo 'alert("Incorrect username, password or create new account!")';
echo '</script>';

 }
 else{
  $_SESSION["user"] = $username;
  $_SESSION["usertype"] = "Customer";
  header("Location: cataloque.php");

  }

  }
}

if($usertype == "Admin")
{
    
@$admin_name =$_POST['username'];
@$password = $_POST['password'];

@$Check_2 = "SELECT * FROM admin WHERE admin_name = '$admin_name' AND password='$password'";
                    $query = $db->query($Check_2);
                    $count = count($query->fetchAll());

if(@$_POST['submit'] == "Login"){

 if(@$count <= 0 ){
 

echo '<script language="javascript">';
echo 'alert("Incorrect Admin name, Password or Contact your system technician!")';
echo '</script>';
 }
 else{
  $_SESSION["user"] = $admin_name;
  $_SESSION["usertype"] = "Admin";
  header("Location: admin_dashboard.php");

  }

  } 
            
}

if($usertype == "Select user type")
{
 
echo '<script language="javascript">';
echo 'alert("Please select user type!")';
echo '</script>';   
} 
     ?> 

<div class="cleared"></div>
                    </div>
                </div>
		<div class="cleared"></div>
    </div>
</div>
<div class="art-block">
    <div class="art-block-body">
                
                <div class="art-blockcontent">
                
                </div>
		<div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                    <div class="art-layout-cell art-content">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner art-article">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<?php

include('conn.php');
@$user = $_SESSION['user'];

if(@$_SESSION['usertype'] == "Customer")
{
    @$select = mysql_query("SELECT * FROM user WHERE username = '$user'");
    @$row = mysql_fetch_array($select);
    echo "<font size='2px'>Welcome <b>". $name = $row['first_name'].' '.$surname = $row['last_name'].'</b>, customer</font>';
}
if(@$_SESSION['usertype'] == "Admin")
{
    @$admin_select = mysql_query("SELECT * FROM admin WHERE admin_name = '$user'");
    @$rows = mysql_fetch_array($admin_select);
    echo "<font size='2px'>You are logged in as <b>". $admin = $rows['admin_name'].'</b>, admin</font>';
}
?>
                                <h2 class="art-postheader">
              ATHEALTH ONLINE SYSTEM WELCOME YOU
                                </h2>
                <div class="cleared"></div>
                                <div class="art-postcontent">


                </div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-t"></div>
                <div class="art-footer-l"></div>
                <div class="art-footer-b"></div>
                <div class="art-footer-r"></div>
                <div class="art-footer-body">
                            <div class="art-footer-text"><br>
                                <p> Copyright © 2018 ATHEALTH SYSTEM. All Rights Reserved.</p>
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
   
</div>

</body>
</html>
