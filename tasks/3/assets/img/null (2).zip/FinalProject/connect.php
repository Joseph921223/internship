<?php

$dsn = 'mysql:dbname=vehicle_parts;host=127.0.0.1';
$username = 'root';
$password = '';

try {
		$db = new PDO($dsn, $username, $password); 

    }
catch (PDOException $e)
	{
		echo "<div class ='error'>Sorry, failed to connect to the database!</div>";
	}

?>