<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
<?php

session_start();
ob_start();

if(!isset($_SESSION["user"]))
{

header("Location: index.php");

}

?>   
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Checkout</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />

    <script language="JavaScript" type="text/javascript" src="js/calender.js"></script>
    <script language="JavaScript" type="text/javascript" src="js/events.js"></script>
</head>
<body background="1.jpg">
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-png"></div>
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-logo">
                                <h1 style="color:#0000ff;" class="art-logo-name">ALTHEALTH ONLINE CARE-SHOP </h1>
                                                 <h2 class="art-logo-text">The number one online health system you can trust</h2>
												
                                </div>
            </div>
            <div class="cleared reset-box"></div>
<div class="art-nav">
    <div class="art-nav-l"></div>
    <div class="art-nav-r"></div>
<div class="art-nav-outer">
    <ul class="art-hmenu">
        <li>
            <a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
        </li>   
        <li>
            <a href="cataloque.php"><span class="l"></span><span class="r"></span><span class="t">Cataloque</span></a>
        </li>
        <li>
            <a href="search.php"><span class="l"></span><span class="r"></span><span class="t">Search</span></a>
        </li>
       
             <li>
            <a href="p_history.php"><span class="l"></span><span class="r"></span><span class="t">My Transaction History</span></a>
             </li>
             <li>
            <a href="register.php"><span class="l"></span><span class="r"></span><span class="t">Register</span></a>
        </li>
             <li>
            <?php

if(!isset($_SESSION["user"]))
{
    echo '<a href="index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>';

}
else
{

   echo '<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>';

}
?>
        </li>
    </ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    <div class="art-layout-cell art-sidebar1">
<div class="art-vmenublock">
    <div class="art-vmenublock-body">
               

    </div>
</div>
<div class="art-block">
    <div class="art-block-body">
                
                <div class="art-blockcontent">
                
                </div>
        <div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                    <div class="art-layout-cell art-content">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner ">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php

include('conn.php');
@$user = $_SESSION['user'];

if(@$_SESSION['usertype'] == "Customer")
{
    @$select = mysql_query("SELECT * FROM user WHERE username = '$user'");
    @$row = mysql_fetch_array($select);
    echo "<font size='2px'>Welcome <b>". $name = $row['first_name'].' '.$surname = $row['last_name'].'</b>, customer</font>';
}
if(@$_SESSION['usertype'] == "Admin")
{
    @$admin_select = mysql_query("SELECT * FROM admin WHERE admin_name = '$user'");
    @$rows = mysql_fetch_array($admin_select);
    echo "<font size='2px'>You are logged in as <b>". $admin = $rows['admin_name'].'</b>, admin</font>';
}
?>
                                <h2 class="art-postheader">
               Checkout
                                </h2>

<table width="" height=""><tr style='background-color: #7999DD'>
<td>&nbsp;&nbsp;<strong>Product Name</strong></td><td>&nbsp;&nbsp;<strong>Quantity</strong></td><td>&nbsp;&nbsp;<strong>SubTotal</strong></td>
<td>&nbsp;&nbsp;<strong>Action</strong></td>
<?php

include("conn.php");
@$userID =$_SESSION['user'];
@$result = mysql_query("SELECT * FROM checkout WHERE username ='$userID' ORDER BY product_id"); 

while(@$row = mysql_fetch_array($result)){
$inventoryID=$row['product_id'];

$get_product = mysql_query("SELECT name FROM products WHERE product_id='$inventoryID'");
$fetch= mysql_fetch_array($get_product);
echo "<tr><td>&nbsp;&nbsp;";
echo $fetch['name'];
echo "</td><td>&nbsp;&nbsp;";
echo $row['nr_of_product_to_purchase'];
echo"</td><td>&nbsp;&nbsp;";
echo number_format($row['total']);
echo "</td><td>&nbsp;&nbsp;";
echo "<a href=remove_cart.php?product_id=$inventoryID&insert=yes><font color='red'>Remove</font></a>";
echo "</td>";
echo "</tr>";
}
echo "</table></center><br>";
echo "<a href='cataloque.php'>Add another item to your cart</a><br><br>";
@$useridCheck= mysql_num_rows(mysql_query("SELECT * FROM shopping_cart_items WHERE userID ='$userID'"));


$order_amount = mysql_query("SELECT SUM(total) as 'Total',product_id,nr_of_product_to_purchase  FROM checkout WHERE username = '$userID'");

$row = mysql_fetch_array($order_amount);
$inventoryID = $row['product_id'];
$quantity = $row['nr_of_product_to_purchase'];
$subtotal = $row['Total'];

$Total = $subtotal * 0.14;
$Total2 = $subtotal + $Total;
echo "<table border='0' width='' height=''><form action='finalise_shopping.php' method='POST'>
<tr><td ></td><td><b>Total Amount before tax: </b></td>
<td style='color: red'><b>R".number_format($subtotal)."</b></td></tr><tr><td width=''></td><td></td>
<td></td></tr><tr><td></td><td><span class='d'><b>Tax:</b></span></td><td style='color: red'><b>@14%</b></td></tr><tr><td></td>
<td><span class='d'><b>Total Amount after tax:</b></span></td><td style='color: red'><b>R".number_format($Total2)."</b></td></tr><tr><td></td><td>
<br><input style='background-color: #FF9966; color: #3366CC' type='submit' name='submit' value='Place Order'><br><br> </td></tr></from></table>"; 

@$amount = $_POST['amount'];
@$tax= $_POST['tax'];
@$order_num = mt_rand(100000, 999999);
@$date = date('Y/m/d');

@$place_order = "INSERT INTO order_details(username,total_amount,order_number,order_status,c_date)
VALUES
('$userID','$Total2','$order_num','Payment Awaiting','$date')";

@$delete = "DELETE FROM  checkout WHERE username = '$userID'";
@$get = mysql_query("SELECT * FROM checkout WHERE username ='$userID' ORDER BY product_id"); 

if($_SERVER["REQUEST_METHOD"] == "POST")
{

mysql_query($place_order);
while(@$row = mysql_fetch_array($get)){
$id=$row['product_id'];
$qt = $row['nr_of_product_to_purchase'];
$update = "UPDATE products SET nr_of_products = nr_of_products - '$qt' WHERE product_id = '$id'";
mysql_query($update);
}
mysql_query($delete);
echo "Your order has been placed. You will receive it in approximately 7 days ";
echo "Order Number: $order_num . <a href='p_history.php'>Click here to continue..</a>";


}

?>              <div class="cleared"></div>
                                <div class="art-postcontent">

                </div>
                <div class="cleared"></div>
                </div>

        <div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-t"></div>
                <div class="art-footer-l"></div>
                <div class="art-footer-b"></div>
                <div class="art-footer-r"></div>
                <div class="art-footer-body">
                            <div class="art-footer-text"><br>
                                Copyright © 2017 MCcarthy Motor Vehicle Parts (Online Retailing System). All Rights Reserved.</p>
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
            <div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer">Developed by Given.</p>
</div>

</body>
</html>
