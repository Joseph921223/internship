<?php

session_start();
session_destroy();
if(isset($_SESSION["user"]))
{

echo "<font size='4px'>You are successfully logout. Click <a href='index.php'>here</a> to continue...</font>";
}

?> 

